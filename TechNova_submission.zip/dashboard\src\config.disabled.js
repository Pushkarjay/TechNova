// Prototype config for local dashboard (development only). Do NOT commit to public repos.
window.APP_CONFIG = {
  GOOGLE_MAPS_API_KEY: 'AIzaSyA0aIKh_IG-hmaxgWDnxlUewtAcAaGZInk',
  FIREBASE_CONFIG: {
    apiKey: 'AIzaSyA0aIKh_IG-hmaxgWDnxlUewtAcAaGZInk',
    authDomain: 'technova-gulu.firebaseapp.com',
    projectId: 'technova-gulu',
    storageBucket: 'technova-gulu.appspot.com',
    messagingSenderId: '860623861748',
    appId: '1:860623861748:web:0000000000000000000000'
  },
  CLOUDINARY: {
    cloudName: 'do7jligxg',
    apiKey: '537937134967534',
    uploadPreset: 'Technova'
  }
};
